require('dotenv').config()

const express = require('express');
const { MongoClient } = require('mongodb');
const mongoose = require('mongoose')
const app = express();
const port = 3000;

app.use(express.json()); // Middleware to parse JSON bodies

// MongoDB connection URL and Database name
const mongoUrl = 'mongodb://localhost:27017';
const dbName = 'blogPlatform';


mongoose.connect(process.env.MONGO_URI,{useNewUrlParser:true})
const db = mongoose.connection
db.on('error',(error)=>console.error(error))
db.once('open',()=>console.log('Mongodb is connected'))



// POST /posts - Add a new blog post:

app.post('/posts', async (req, res) => {
    try {
      const { userName, title, content } = req.body;
      const collection = db.collection('posts');
      const result = await collection.insertOne({ userName, title, content });
  
      res.status(201).send(result);
    } catch (err) {
      console.error(err);
      res.status(500).send("Failed to create post.");
    }
  });

  
  // GET /posts - Retrieve all blog posts:

  app.get('/posts', async (req, res) => {
    try {
      const collection = db.collection('posts');
      const posts = await collection.find({}).toArray();
      res.json(posts);
    } catch (err) {
      console.error(err);
      res.status(500).send("Failed to fetch posts.");
    }
  });
  

  // GET /posts/user/:userName - Retrieve all posts by username

  app.get('/posts/user/:userName', async (req, res) => {
    const userName = req.params.userName;
    try {
      const collection = db.collection('posts');
      const posts = await collection.find({ userName }).toArray();
      res.json(posts);
    } catch (err) {
      console.error(err);
      res.status(500).send("Failed to fetch posts.");
    }
  });

  
  // GET /posts/title/:searchWord

  app.get('/posts/title/:searchWord', async (req, res) => {
    const searchWord = req.params.searchWord;
    try {
      const collection = db.collection('posts');
      const posts = await collection.find({ title: { $regex: searchWord, $options: 'i' } }).toArray();
      res.json(posts);
    } catch (err) {
      console.error(err);
      res.status(500).send("Failed to fetch posts.");
    }
  });
  

  //  GET /posts/content/:searchWord

  app.get('/posts/content/:searchWord', async (req, res) => {
    const searchWord = req.params.searchWord;
    try {
      const collection = db.collection('posts');
      const posts = await collection.find({ content: { $regex: searchWord, $options: 'i' } }).toArray();
      res.json(posts);
    } catch (err) {
      console.error(err);
      res.status(500).send("Failed to fetch posts.");
    }
  });
  

  // DELETE /posts/user/:userName

  app.delete('/posts/user/:userName', async (req, res) => {
    const userName = req.params.userName;
    try {
      const collection = db.collection('posts');
      const result = await collection.deleteMany({ userName });
      res.send(result);
    } catch (err) {
      console.error(err);
      res.status(500).send("Failed to delete posts.");
    }
  });
  

  // DELETE /posts/content/:searchWord

  app.delete('/posts/content/:searchWord', async (req, res) => {
    const searchWord = req.params.searchWord;
    try {
      const collection = db.collection('posts');
      const result = await collection.deleteMany({ content: { $regex: searchWord, $options: 'i' } });
      if (result.deletedCount === 0) {
        return res.status(404).send("No posts found with the specified content.");
      }
      res.json({ message: "Posts deleted successfully.", deletedCount: result.deletedCount });
    } catch (err) {
      console.error(err);
      res.status(500).send("Failed to delete posts.");
    }
  });
  



  // GET /posts/count/:userName

  app.get('/posts/count/:userName', async (req, res) => {
    const userName = req.params.userName;
    try {
      const collection = db.collection('posts');
      const count = await collection.countDocuments({ userName });
      res.json({ userName, count });
    } catch (err) {
      console.error(err);
      res.status(500).send("Failed to count posts.");
    }
  });

  app.listen(port, () => console.log("Blog platform API listening at http://localhost:${port}"));